const vscode = require('vscode');
const axios = require('axios');
require('dotenv').config();

function activate(context) {
  console.log('Groq Code Reviewer Extension Activated');

  let disposable = vscode.commands.registerCommand('groqCodeReviewer.reviewCode', async function () {
    const editor = vscode.window.activeTextEditor;

    // Ensure there is an active editor
    if (!editor) {
      vscode.window.showErrorMessage('❌ No active editor found. Please open a file to review.');
      return;
    }

    const code = editor.document.getText();

    // Ensure the file is not empty
    if (!code || code.trim().length === 0) {
      vscode.window.showWarningMessage('⚠ The current file is empty. Please provide code to review.');
      return;
    }

    const apiKey = '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'; // You can hardcode it here if you want

    try {
      vscode.window.showInformationMessage('🔍 Reviewing your code with Groq...');

      const prompt = `Act as a vulnerability-focused code reviewer. Your response must be in Markdown and follow this format strictly:

### 🔴 Original Code (user’s input)
\`red
[The problematic portion of the input code here, in red font]
\`

### 🟢 Improved Version (only fixed portion)
\`green
[Only the corrected portion, in green font]
\`

### ✅ Explanation
[Explain the vulnerabilities you fixed clearly.]

Always show buttons:
[Accept ✅] [Reject ❌]

Now review this code:

${code}
`;

      const response = await axios.post(
        'https://api.groq.com/openai/v1/chat/completions',
        {
          model: 'llama-3.3-70b-versatile',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const review = response.data.choices[0].message.content;

      const panel = vscode.window.createWebviewPanel(
        'groqReview',
        'Groq Code Review Result',
        vscode.ViewColumn.Beside,
        { enableScripts: true }
      );

      panel.webview.html = getWebviewContent(review);

      // Listen for the accept/reject messages from the webview
      panel.webview.onDidReceiveMessage((message) => {
        switch (message.action) {
          case 'accept':
            // Extract the improved code and replace it in the editor
            const improvedCode = extractImprovedCode(review); // Extract the improved code from the review

            if (improvedCode) {
              // Set the entire editor's text with the improved code
              editor.edit((editBuilder) => {
                editBuilder.replace(
                  new vscode.Range(
                    editor.document.positionAt(0), // Start at the beginning of the document
                    editor.document.positionAt(editor.document.getText().length) // End at the last character
                  ),
                  improvedCode
                );
              }).then(() => {
                vscode.window.showInformationMessage('✅ Accept button clicked and code updated');
              });
            } else {
              vscode.window.showErrorMessage('❌ Failed to extract improved code from the review.');
            }
            break;
          case 'reject':
            vscode.window.showInformationMessage('❌ Reject button clicked');
            break;
        }
      });

    } catch (error) {
      console.error('Groq API error:', error);
      vscode.window.showErrorMessage('❌ Failed to review code: ' + error.message);
    }
  });

  context.subscriptions.push(disposable);
}

function getWebviewContent(reviewMarkdown) {
  const md = require('markdown-it')({ html: true });
  const htmlContent = md.render(reviewMarkdown);

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: sans-serif; padding: 20px; }
        .buttons {
          margin-top: 20px;
        }
        button {
          padding: 10px 20px;
          font-size: 16px;
          margin-right: 10px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }
        .accept { background-color: #4CAF50; color: white; }
        .reject { background-color: #f44336; color: white; }
      </style>
    </head>
    <body>
      ${htmlContent}
      <div class="buttons">
        <button class="reject" onclick="vscode.postMessage({ action: 'reject' })">❌ Reject</button>
      </div>
      <script>
        const vscode = acquireVsCodeApi();

        // Send action when Accept or Reject button is clicked
        window.addEventListener('message', event => {
          const message = event.data;
          if (message.action === 'accept') {
            vscode.postMessage({ action: 'accept' });
            alert('✅ Accept button clicked');
          } else if (message.action === 'reject') {
            vscode.postMessage({ action: 'reject' });
            alert('❌ Reject button clicked');
          }
        });
      </script>
    </body>
    </html>
  `;
}

function extractImprovedCode(review) {
  try {
    // Normalize line endings
    const normalized = review.replace(/\r\n/g, '\n');

    // Find "Improved Version" section start
    const startMarker = "### 🟢 Improved Version";
    const endMarker = "### ✅ Explanation";

    const startIdx = normalized.indexOf(startMarker);
    const endIdx = normalized.indexOf(endMarker);

    if (startIdx === -1 || endIdx === -1 || endIdx <= startIdx) {
      throw new Error("Markers not found or in wrong order.");
    }

    const improvedSection = normalized.substring(startIdx, endIdx);

    // Extract content between triple backticks
    const codeMatch = improvedSection.match(/(?:[a-z]*)?\s*([\s\S]*?)\s*/i);

    if (codeMatch && codeMatch[1]) {
      return codeMatch[1].trim();
    } else {
      throw new Error("Failed to match code block within Improved Version section.");
    }
  } catch (err) {
    console.error('extractImprovedCode error:', err);
    vscode.window.showErrorMessage('❌ Failed to extract improved code from the review.');
    return '';
  }
}

function deactivate() {}

module.exports = {
  activate,
  deactivate
};